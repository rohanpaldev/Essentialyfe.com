<?php error_reporting(E_ALL ^ E_NOTICE); ?>
<?php 
include("./config.php");
// $tblprefix= "essentials_";
$currentDate = date("Y-m-d H:i:s");

if(isset($_POST['subscribeNewsLetter'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $chknewsltr = mysqli_query($conn,"SELECT `email` FROM `".$tblPrefix."`newsletter` WHERE `email` = '$email' ");

    if(mysqli_num_rows($chknewsltr)==0){
     $newsubscription = mysqli_query($conn, "INSERT INTO ".$tblprefix."`newsletter`(`email`, `date`) VALUES ('$email','$currentDate')");
    }
    // print_r($newsubscription);
    // mysqli_error($conn);
    if($newsubscription){
        echo "<div class='alert alert-success' role='alert'>
        Your newsletter has been submitted.
        </div>";
      
    }else{
        echo "<div class='alert alert-danger' role='alert'>
        Your newsletter not Submitted.
        </div>";
  
    }
}
?>